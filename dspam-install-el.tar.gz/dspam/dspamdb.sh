#!/bin/sh

#
# DSPAM install script for RHEL (and Clones) 5 & 6 
# Written by Eric C. Broch of White Horse Technical Consulting, January 26, 2014
#
# Use this script at your own risk. If you do use it and the bottom drops out of 
# your world, I will accept no responsibilty.
#


DOMAIN=
MYSQLPW=

# Check whether MySQL is installed, if not install it or exit.
echo "Checking for mysql server..."
rpm -qa | grep mysql-server > /dev/null 2>&1
if [ "$?" != "0" ]; then
   echo "MySQL Server not installed"
   read -p "Install MySQL server? [y/n] :" input
   if [ "$input" = "Y" ] || [ "$input" = "y" ]; then
      yum -y install mysql-server
   else
      exit 1
   fi
else
   echo "MySQL Server present"
fi

# Enable MySQL Server, if not exit.
echo "Enabling MySQL Server..."
chkconfig mysqld on
if [ "$?" != "0" ]; then
   echo "MySQL server daemon not enabled. Exiting..."
   exit
fi

# Start MySQL Server, if not exit.
echo "Staring MySQL Server..."
service mysqld start
if [ "$?" != "0" ]; then
   echo "MySQL server not started. Exiting..."
   exit 1
fi

# Get MySQL password for administrator.
if [ -z "$MYSQLPW" ]; then
   read -p "There is no MySQL administrator password, Please enter one: " MYSQLPW
fi

# Check if entered password is valid.
mysqladmin status -uroot -p$MYSQLPW > /dev/null 2>&1
if [ "$?" != "0" ]; then
   echo "Bad MySQL Server administrator password. Exiting..."
   exit 1
fi

# Check if destroying dspam database is desired
read -p "If there is a dspam database, you are about to destroy it and create a new one. Proceed? [Y/N]: " input
if [ "$input" != "Y" ] && [ "$input" != "y" ]; then
   echo "Exiting..."
fi

# Create dspam with correct permissions
mysqladmin drop dspam -uroot -p$MYSQLPW
mysqladmin create dspam -uroot -p$MYSQLPW
mysqladmin -uroot -p$MYSQLPW reload
mysqladmin -uroot -p$MYSQLPW refresh

echo "GRANT ALL ON dspam.* TO dspam@localhost IDENTIFIED BY 'p4ssw3rd'" | mysql -uroot -p$MYSQLPW
mysqladmin -uroot -p$MYSQLPW reload
mysqladmin -uroot -p$MYSQLPW refresh

mysql -uroot -p$MYSQLPW dspam < ./dspamdb.sql
mysqladmin -uroot -p$MYSQLPW reload
mysqladmin -uroot -p$MYSQLPW refresh

# Install EPEL Repository if not installed
if [ ! -f /etc/yum.repos.d/epel.repo ]; then
   echo "Installing EPEL repository..."
   epelrel=
   ARCH=`uname -m`
   if [ ! -f /etc/redhat-release ]; then
      echo "Not a CentOS system. Exiting..."
      exit 1
   fi
   RELEASE=`cat /etc/redhat-release | cut -d" " -f3 | cut -d"." -f1`
   if [ "$RELEASE" = "5" ]; then
      epelrel=epel-release-5-4.noarch.rpm
   elif [ "$RELEASE" = "6" ]; then
      epelrel=epel-release-6-8.noarch.rpm
   else
      echo "Unknown release: $RELEASE. Exiting..."
      exit 1
   fi
   wget http://dl.fedoraproject.org/pub/epel/$RELEASE/$ARCH/$epelrel
   if [ "$?" != "0" ]; then
      echo "Error downloading EPEL repo. Exiting..."
      exit 1
   fi
   rpm -Uvh epel-release-*.noarch.rpm
   if [ "$?" != "0" ]; then
      echo "Error installing EPEL repo. Exiting..."
      exit 1
   fi
else
   echo "EPEL present on system. Continuing..."
fi

# Install dspam rpm's if not installed.
echo "Checking for dspam installation..."
rpm -qa | grep dspam > /dev/null 2>&1
if [ "$?" != "0" ]; then
   yum -y install dspam
fi
echo "Checking for dspam-client installation..."
rpm -qa | grep dspam-client > /dev/null 2>&1
if [ "$?" != "0" ]; then
   yum -y install dspam-client
fi
echo "Checking for dspam-mysql installation..."
rpm -qa | grep dspam-mysql > /dev/null 2>&1
if [ "$?" != "0" ]; then
   yum -y install dspam-mysql
fi

# Change permissions on and place proper files necessary to run dspam daemon
chmod 777 /var/run/dspam

mv /etc/dspam.conf /etc/dspam.conf.bak
cp -p  /root/dspam/dspam.conf /etc/dspam.conf

chmod 744 /etc/dspam.conf

# Implement dspam for all domains
read -p "Implement dspam for domains? [Y/N]: " input
if [ "$input" = "Y" ] || [ "$input" = "y" ]; then
   domdir=/home/vpopmail/domains
   for folder in `ls $domdir`; do
      if [ -d $domdir/$folder ]; then
         read -p "Add dspam functionality to $folder [Y]: " input1
         if [ "$input1" = "Y" ] || [ "$input1" = "y" ]; then
            mv $domdir/$folder/.qmail-default $domdir/$folder/.qmail-default.bak
            cp -p .qmail-default $domdir/$folder
            echo "Domain: $folder ready..."
         else
            echo "Skipping $folder..."
         fi
      fi
   done
fi

# Start dspam service
service dspam start

exit 0
