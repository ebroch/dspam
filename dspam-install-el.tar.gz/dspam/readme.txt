Run the script 'dspamdb.sh' to create the dspam database, install dspam, and start the dspam service:

The configuration file installed is for a local running of dspam on RHEL Clones.

This install doesn't include any training of the use database.

