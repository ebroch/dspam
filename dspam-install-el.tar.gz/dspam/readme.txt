

1) run the script below to create the dspam database, install dspam, and start 
   the dspam service:
./dspamdb.sh

2) copy .qmail-default the domain of your choice, 'mydomain.com' below is a sample,
   to make dspam operable for the domain.
cp -p .qmail-default /home/vpopmail/domains/mydomain.com 


