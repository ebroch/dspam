#!/bin/bash

domdir=/home/vpopmail/domains


for folder in `ls $domdir`; do
   if [ -d $domdir/$folder ]; then
      mv $domdir/$folder/.qmail-default $domdir/$folder/.qmail-default.bak
      cp -p .qmail-default $domdir/$folder
      echo "Domain: $folder ready..."
   fi
done

